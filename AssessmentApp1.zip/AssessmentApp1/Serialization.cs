﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace AssessmentApp1
{
    class Serialization
    {
        [Serializable]

        public class Employee
        {
            public int employeeID { get; set; }
            public string employeeName { get; set; }
            public string employeeAddress { get; set; }
            public long phone { get; set; }
        }

        public static void Main()
        {
            binarySerialization();

            Console.ReadKey();
        }

        private static void binarySerialization()
        {
            Console.WriteLine("Want to read or write");
            string option = Console.ReadLine();
            if (option.ToLower() == "read")
                deserialise();
            else
                serialise();

        }

        private static void serialise()
        {
            //what to serialise
            Employee emp = new Employee{ employeeID = 4556, employeeName = "Angana", employeeAddress = "Mysuru", phone = 11234567890 };
            //how to serialize
            BinaryFormatter bf = new BinaryFormatter();
            //where to serialize
            FileStream fs = new FileStream("Data.bin", FileMode.OpenOrCreate, FileAccess.Write);
            bf.Serialize(fs, emp);
            fs.Close();
        }

        private static void deserialise()
        {
            try
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream fs = new FileStream("Data.bin", FileMode.Open, FileAccess.Read);
                Employee emp = bf.Deserialize(fs) as Employee;
                Console.WriteLine(emp.employeeName);
                fs.Close();
            }

            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
