﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NewWebApplication.Models;

namespace NewWebApplication.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }

        //view all customers
        public ViewResult AllCustomer()
        {
            var context = new LnTassessmentEntities();
            var model = context.CustomerTables.ToList();
            return View(model);
        }


        public ViewResult Find(string id)
        {
            int cstId = int.Parse(id);
            var context = new LnTassessmentEntities();
            var model = context.CustomerTables.FirstOrDefault((c) => c.CustomerId == cstId);
            return View(model);

        }
        //ActionResult is the abstract class for all kinds of action returns....
        [HttpPost]
        public ActionResult Find(CustomerTable cst)
        {
            var context = new LnTassessmentEntities();
            var model = context.CustomerTables.FirstOrDefault((c) => c.CustomerId == cst.CustomerId);
            model.CustomerName = cst.CustomerName;
            model.CustomerAddress = cst.CustomerAddress;
            model.Phone = cst.Phone;
            context.SaveChanges();//Commits the changes made to the records...
            return RedirectToAction("AllCustomer");
        }

        public ViewResult NewEmployee()
        {
            var model = new CustomerTable(); //empty
            return View(model);
        }

        [HttpPost]
        public ActionResult NewEmployee(CustomerTable cst)
        {
            var context = new LnTassessmentEntities();
            context.CustomerTables.Add(cst);
            context.SaveChanges();
            return RedirectToAction("AllCustomer");
        }

        public ActionResult Delete(string id)
        {
            //convert string to int
            int cstId = int.Parse(id);
            var context = new LnTassessmentEntities();
            var model = context.CustomerTables.FirstOrDefault((c) => c.CustomerId == cstId);
            context.CustomerTables.Remove(model);
            context.SaveChanges();
            return RedirectToAction("AllCustomer");
        }


    }
}