﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerManagement
{
    class MyConsole
    {
        public static string getString(string str)
        {
            Console.WriteLine(str);
            string value = Console.ReadLine();
            return value;
        }
        public static int getNumber(string str)
        {
            Console.WriteLine(str);
            int value = int.Parse(Console.ReadLine());
            return value;
        }
    }
}
