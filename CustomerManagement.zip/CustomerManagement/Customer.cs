﻿
using System;

namespace CustomerManagement
{
    interface ICustomer
    {
        bool AddNewCustomer(Customer bk);
        bool DeleteCustomer(int id);
        bool UpdateCustomer(Customer bk);
        Customer[] GetAllCustomer(string title);
    }

    class CustomerManager : ICustomer
    {

        private Customer[] allCustomer = null;

        private bool hasCustomer(int id)
        {
            foreach (Customer cust in allCustomer)
            {
                if ((cust != null) && (cust.ID == id))
                    return true;
            }
            return false;

        }
        public CustomerManager(int size)
        {
            allCustomer = new Customer[size];
        }
        public bool AddNewCustomer(Customer cust)
        {
            bool available = hasCustomer(cust.ID);
            if (available)
                throw new Exception("Customer by this ID already exists");
            for (int i = 0; i < allCustomer.Length; i++)
            { 
                if (allCustomer[i] == null)
                {
                    allCustomer[i] = new Customer();
                    allCustomer[i].ID = cust.ID;
                    allCustomer[i].Name = cust.Name;
                    allCustomer[i].Address = cust.Address;
                    return true;
                }
            }
            return false;
        }

        public bool DeleteCustomer(int id)
        {
            for (int i = 0; i < allCustomer.Length; i++)
            {
                if ((allCustomer[i] != null) && (allCustomer[i].ID == id))
                {
                    allCustomer[i] = null;
                    return true;
                }
            }
            return false;
        }

        public Customer[] GetAllCustomer(string name)
        {
            Customer[] copy = new Customer[allCustomer.Length];
            //iterate thro the original to find the matching book.
            int index = 0;
            foreach (Customer cust in allCustomer)
            {
                if ((cust != null) && (cust.Name.Contains(name)))
                {
                    copy[index] = cust;
                    index++;
                }
            }

            //return the copy...
            return copy;
        }

        public bool UpdateCustomer(Customer cust)
        {
            for (int i = 0; i < allCustomer.Length; i++)
            {
                //find the first occurance of null in the array...
                if ((allCustomer[i] != null) && (allCustomer[i].ID == cust.ID))
                {
                    allCustomer[i].Name = cust.Name;
                    allCustomer[i].Address = cust.Address;
                    return true;
                }
            }
            return false;
        }
    }
    class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
    class BookFactoryComponent
    {
        public static ICustomer GetComponent(int size)
        {
            return new CustomerManager(size);
        }
    }
    class UIClient
    {
        static string menu = string.Empty;
        static ICustomer mgr = null;
        static void Initialize()
        {
            menu = string.Format($"~~~~~~~CUSTOMER MANAGEMENT SOFTWARE~~~~~~~~~~~~~~~~~~~\nTO ADD A NEW Customer------------->PRESS 1\nTO UPDATE A CUSTOMER------------>PRESS 2\nTO DELETE A CUSTOMER------------PRESS 3\nTO FIND A CUSTOMER------------->PRESS 4\nPS:ANY OTHER KEY IS CONSIDERED AS EXIT THE APP\n");
            int size = MyConsole.getNumber("Enter the no of Customers you wish to store");
            mgr = BookFactoryComponent.GetComponent(size);
        }

        static void Main(string[] args)
        {
            Initialize();
            bool process = true;
            do
            {
                string choice = MyConsole.getString(menu);
                process = processing(choice);
            } while (process);
        }

        private static bool processing(string choice)
        {
            switch (choice)
            {
                case "1":
                    addingBookFeature();
                    break;
                case "2":
                    updatingBookFeature();
                    break;
                case "3":
                    deletingFeature();
                    break;
                case "4":
                    getCustomerFeature();
                    break;
                default:
                    return false;
            }
            return true;
        }

        private static void getCustomerFeature()
        {
            string name = MyConsole.getString("Enter the name of customer to search");
            Customer[] customer = mgr.GetAllCustomer(name);
            foreach (var cust in customer)
            {
                if (cust != null)
                    Console.WriteLine(cust.Name);
            }
        }

        private static void deletingFeature()
        {
            int id = MyConsole.getNumber("Enter the ID of the Customer to remove");
            if (mgr.DeleteCustomer(id))
                Console.WriteLine("Customer is Deleted successfully");
            else
                Console.WriteLine("Could not find the Customer to delete");
        }

        private static void updatingBookFeature()
        {
            Customer cust = new Customer();
            cust.ID = MyConsole.getNumber("Enter the Id of Customer you wish to update");
            cust.Name = MyConsole.getString("Enter the new name of Customer");
            cust.Address = MyConsole.getString("Enter the new Address of the Customer");
            bool result = mgr.UpdateCustomer(cust);
            if (!result)
                Console.WriteLine($"No Customer by this id {cust.ID} found to update");
            else
                Console.WriteLine($"Customer by ID {cust.ID} is updated successfully to the database");
        }

        private static void addingBookFeature()
        {
            Customer cust = new Customer();
            cust.ID = MyConsole.getNumber("Enter the Id of Customer");
            cust.Name = MyConsole.getString("Enter the name of Customer");
            cust.Address = MyConsole.getString("Enter the Address of Customer");
            try
            {
                bool result = mgr.AddNewCustomer(cust);
                if (!result)
                    Console.WriteLine("No more Customer could be added");
                else
                    Console.WriteLine($"Customer by name {cust.Name} is added successfully to the database");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}